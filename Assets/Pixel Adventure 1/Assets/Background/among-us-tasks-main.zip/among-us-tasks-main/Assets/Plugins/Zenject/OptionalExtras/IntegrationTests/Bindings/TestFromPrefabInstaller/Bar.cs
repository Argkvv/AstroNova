﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefabInstaller
{
    public class Bar : MonoBehaviour
    {
    }
}
