using UnityEngine;

public interface IInputManager
{
    Vector3 InputPosition { get; }
    
}